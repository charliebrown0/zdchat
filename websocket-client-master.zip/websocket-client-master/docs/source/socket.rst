####################
websocket/_socket.py
####################

The _socket.py file

.. automodule:: websocket._socket
  :members:
