############
Installation
############

You can use either ``python3 setup.py install`` or
``pip3 install websocket-client`` to install this library.
