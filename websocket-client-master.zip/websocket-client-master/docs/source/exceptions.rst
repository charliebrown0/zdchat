########################
websocket/_exceptions.py
########################

The _exceptions.py file

.. automodule:: websocket._exceptions
  :members:
