#####################
websocket/_logging.py
#####################

The _logging.py file

.. automodule:: websocket._logging
  :members:
